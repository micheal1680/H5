module.exports = require('./build/standalone');
